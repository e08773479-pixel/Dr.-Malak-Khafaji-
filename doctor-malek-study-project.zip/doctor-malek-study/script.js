const $ = (s, p=document) => p.querySelector(s);
const $$ = (s, p=document) => [...p.querySelectorAll(s)];

const defaults = {
  studentName: "ملك",
  weeklyGoal: 900,
  goalMessage: "يارب ملك تجيب 100%",
  totalMinutes: 0,
  sessions: [
    {subject:"رياضيات", duration:45, time:"09:00 ص", done:true},
    {subject:"فيزياء", duration:45, time:"11:00 ص", done:true},
    {subject:"كيمياء", duration:45, time:"01:00 م", done:false},
    {subject:"أحياء", duration:45, time:"03:00 م", done:false}
  ],
  tasks: [
    {text:"حل 20 مسألة رياضيات", done:false},
    {text:"مراجعة درس الفيزياء", done:true},
    {text:"قراءة فصل الأحياء", done:false}
  ],
  notes: [
    {text:"ركزي على النقاط الصعبة قبل الامتحان."},
    {text:"كل جلسة صغيرة بتقربك من هدفك."}
  ],
  schedule: [
    {day:"السبت", time:"09:00", subject:"رياضيات"},
    {day:"الأحد", time:"11:00", subject:"فيزياء"},
    {day:"الإثنين", time:"10:00", subject:"كيمياء"}
  ],
  prayerTimes: {الفجر:"05:05", الظهر:"12:05", العصر:"15:35", المغرب:"18:25", العشاء:"19:45"},
  weekly: [35,60,80,50,90,45,70]
};

let data = JSON.parse(localStorage.getItem("doctorMalekData") || "null") || structuredClone(defaults);
const save = () => localStorage.setItem("doctorMalekData", JSON.stringify(data));

let selectedMode = 45;
let remaining = selectedMode * 60;
let timer = null;
let ambientCtx = null, ambientGain = null, ambientOsc = null, adhanCtx = null;

const motivations = [
  ["يارب ملك تجيب 100%","ثقي في نفسك، أنتِ قدها 💗"],
  ["كل دقيقة مذاكرة بتقربك من حلمك","الاستمرار أهم من الكمال ✨"],
  ["ملكة النهارده، دكتورة بكرة","تعبك مش بيروح هدر 👑"],
  ["خدي نفس وكملي","النجاح بيحب اللي بيكمل حتى وهو تعبان 💪"]
];

function formatTime(sec){
  const m = Math.floor(sec/60).toString().padStart(2,"0");
  const s = (sec%60).toString().padStart(2,"0");
  return `${m}:${s}`;
}
function renderTimer(){
  $("#timerDisplay").textContent = formatTime(remaining);
  const total = selectedMode * 60;
  const progress = Math.max(0, Math.min(360, ((total-remaining)/total)*360));
  $("#timerRing").style.background = `conic-gradient(var(--pink) 0deg, var(--purple) ${progress}deg, rgba(255,255,255,.1) ${progress}deg 360deg)`;
}
function startTimer(){
  if(timer) return;
  $("#playTimer").textContent = "Ⅱ";
  timer = setInterval(()=>{
    if(remaining <= 0){
      clearInterval(timer); timer=null; $("#playTimer").textContent="▶";
      finishSession(); gentleBell();
      return;
    }
    remaining--; renderTimer();
  },1000);
}
function stopTimer(){clearInterval(timer);timer=null;$("#playTimer").textContent="▶";}
function finishSession(){
  data.totalMinutes += selectedMode;
  data.sessions.unshift({subject:"جلسة تركيز",duration:selectedMode,time:new Date().toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"}),done:true});
  data.weekly[(new Date().getDay()+1)%7] += selectedMode;
  save(); renderAll();
}
$("#playTimer").onclick=()=>timer?stopTimer():startTimer();
$("#stopTimer").onclick=stopTimer;
$("#resetTimer").onclick=()=>{stopTimer();remaining=selectedMode*60;renderTimer();};
$$(".mode-btn").forEach(btn=>btn.onclick=()=>{
  stopTimer(); selectedMode=+btn.dataset.minutes; remaining=selectedMode*60;
  $("#sessionTitle").textContent=btn.dataset.title;
  $$(".mode-btn").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderTimer();
});

function renderSessions(){
  const list=$("#sessionList"), all=$("#allSessions");
  list.innerHTML=""; all.innerHTML="";
  data.sessions.slice(0,5).forEach((s,i)=>{
    const html=`<div class="session-item"><span class="subject">${s.subject}</span><small>${s.time}</small><span>${s.duration}:00</span><span class="session-status">${s.done?"●":"◷"}</span></div>`;
    list.insertAdjacentHTML("beforeend",html); all.insertAdjacentHTML("beforeend",html);
  });
  const today = data.sessions.reduce((a,s)=>a+s.duration,0);
  $("#todayTotal").textContent=`${today} د`;
}
function renderStats(){
  const hours=(data.totalMinutes/60).toFixed(data.totalMinutes<60?1:0);
  $("#totalTime").textContent=`${hours} س`;
  $("#sessionCount").textContent=data.sessions.length;
  $("#streak").textContent=Math.max(1, Math.min(7, data.sessions.filter(s=>s.done).length));
  $("#doneTasks").textContent=data.tasks.filter(t=>t.done).length;
  const max=Math.max(...data.weekly,1);
  const bars=data.weekly.map(v=>`<div class="bar" style="height:${Math.max(8,(v/max)*100)}%"></div>`).join("");
  $("#weekChart").innerHTML=bars;
  $("#largeChart").innerHTML=data.weekly.map(v=>`<div class="bar" style="height:${Math.max(8,(v/max)*100)}%"><span></span></div>`).join("");
}
function renderTasks(){
  const list=$("#taskList");list.innerHTML="";
  data.tasks.forEach((t,i)=>{
    const row=document.createElement("div");row.className="task-item"+(t.done?" done":"");
    row.innerHTML=`<input type="checkbox" ${t.done?"checked":""}><span class="task-text">${escapeHtml(t.text)}</span><button title="حذف">🗑</button>`;
    $("input",row).onchange=e=>{data.tasks[i].done=e.target.checked;save();renderTasks();renderStats();};
    $("button",row).onclick=()=>{data.tasks.splice(i,1);save();renderTasks();renderStats();};
    list.appendChild(row);
  });
}
function renderNotes(){
  $("#notesGrid").innerHTML=data.notes.map((n,i)=>`<div class="note">${escapeHtml(n.text)}<br><button class="text-btn delete-note" data-i="${i}">حذف</button></div>`).join("");
  $$(".delete-note").forEach(b=>b.onclick=()=>{data.notes.splice(+b.dataset.i,1);save();renderNotes();});
}
function renderSchedule(){
  $("#scheduleGrid").innerHTML=data.schedule.map((s,i)=>`<div class="schedule-item"><strong>${escapeHtml(s.subject)}</strong><br><small>${escapeHtml(s.day)} — ${escapeHtml(s.time)}</small><br><button class="text-btn del-schedule" data-i="${i}">حذف</button></div>`).join("");
  $$(".del-schedule").forEach(b=>b.onclick=()=>{data.schedule.splice(+b.dataset.i,1);save();renderSchedule();});
}
function renderPrayerSettings(){
  const c=$("#prayerSettings");c.innerHTML="";
  Object.entries(data.prayerTimes).forEach(([name,time])=>{
    c.insertAdjacentHTML("beforeend",`<label>${name}<input type="time" data-prayer="${name}" value="${time}"></label>`);
  });
}
function updatePrayerCard(){
  const now=new Date(), nowM=now.getHours()*60+now.getMinutes();
  const arr=Object.entries(data.prayerTimes).map(([name,time])=>{let [h,m]=time.split(":").map(Number);return {name,time,mins:h*60+m};}).sort((a,b)=>a.mins-b.mins);
  let next=arr.find(x=>x.mins>nowM);
  if(!next) next={...arr[0],mins:arr[0].mins+1440};
  const diff=next.mins-nowM;
  $("#nextPrayerName").textContent=next.name;
  $("#nextPrayerTime").textContent=next.time;
  $("#adhanCountdown").textContent=`باقي ${Math.floor(diff/60)} س ${diff%60} د على الأذان`;
}
function renderSettings(){
  $("#studentName").value=data.studentName;$("#weeklyGoal").value=data.weeklyGoal;$("#goalMessage").value=data.goalMessage;
  $("#motivationText").innerHTML=escapeHtml(data.goalMessage).replace("100%","<span>100%</span>");
  $(".profile span").textContent=data.studentName;
}
function renderAll(){renderSessions();renderStats();renderTasks();renderNotes();renderSchedule();renderPrayerSettings();updatePrayerCard();renderSettings();}

function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

const modal=$("#modal"), modalBody=$("#modalBody");
function openModal(title, html, saveFn){
  $("#modalTitle").textContent=title;modalBody.innerHTML=html;modal.classList.add("show");
  $("#modalSave").onclick=()=>{if(saveFn())modal.classList.remove("show");};
}
$("#modalClose").onclick=()=>modal.classList.remove("show");
modal.onclick=e=>{if(e.target===modal)modal.classList.remove("show");};

$("#addTask").onclick=()=>openModal("إضافة مهمة",`<label>المهمة<input id="newText" placeholder="اكتبي المهمة"></label>`,()=>{const v=$("#newText").value.trim();if(!v)return false;data.tasks.push({text:v,done:false});save();renderTasks();renderStats();return true;});
$("#addNote").onclick=()=>openModal("ملاحظة جديدة",`<textarea id="newText" placeholder="اكتبي ملاحظتك"></textarea>`,()=>{const v=$("#newText").value.trim();if(!v)return false;data.notes.push({text:v});save();renderNotes();return true;});
$("#addSession").onclick=()=>openModal("جلسة جديدة",`<label>المادة<input id="newSubject" placeholder="مثال: رياضيات"></label><label>المدة بالدقائق<input id="newDuration" type="number" value="45"></label>`,()=>{const s=$("#newSubject").value.trim(),d=+$("#newDuration").value;if(!s||!d)return false;data.sessions.unshift({subject:s,duration:d,time:new Date().toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"}),done:false});save();renderSessions();return true;});
$("#addSchedule").onclick=()=>openModal("إضافة موعد",`<label>المادة<input id="newSubject"></label><label>اليوم<input id="newDay" placeholder="مثال: السبت"></label><label>الوقت<input id="newTime" type="time"></label>`,()=>{let s=$("#newSubject").value.trim(),d=$("#newDay").value.trim(),t=$("#newTime").value;if(!s||!d||!t)return false;data.schedule.push({subject:s,day:d,time:t});save();renderSchedule();return true;});

$("#newMotivation").onclick=()=>{const m=motivations[Math.floor(Math.random()*motivations.length)];$("#motivationText").innerHTML=m[0].replace("100%","<span>100%</span>");$("#motivationSub").textContent=m[1];};
$("#savePrayerTimes").onclick=()=>{$$(".prayer-settings input").forEach(i=>data.prayerTimes[i.dataset.prayer]=i.value);save();updatePrayerCard();alert("تم حفظ الأوقات بنجاح 🌙");};
$("#saveSettings").onclick=()=>{data.studentName=$("#studentName").value.trim()||"ملك";data.weeklyGoal=+$("#weeklyGoal").value||900;data.goalMessage=$("#goalMessage").value.trim()||"يارب ملك تجيب 100%";save();renderSettings();alert("تم حفظ الإعدادات ✨");};
$("#clearData").onclick=()=>{if(confirm("هل تريدين مسح كل البيانات المحلية؟")){data=structuredClone(defaults);save();renderAll();}};

function gentleBell(){
  try{
    const c=new (window.AudioContext||window.webkitAudioContext)();
    const g=c.createGain();g.gain.setValueAtTime(.0001,c.currentTime);g.gain.exponentialRampToValueAtTime(.18,c.currentTime+.05);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+2);g.connect(c.destination);
    [523.25,659.25,783.99].forEach((f,i)=>{const o=c.createOscillator();o.frequency.value=f;o.type="sine";o.connect(g);o.start(c.currentTime+i*.16);o.stop(c.currentTime+2);});
  }catch(e){}
}
$("#adhanPlay").onclick=gentleBell;

$("#ambientPlay").onclick=()=>{
  if(ambientOsc){ambientOsc.stop();ambientOsc=null;$("#ambientPlay").textContent="▶";$("#ambientState").textContent="متوقف";return;}
  try{
    ambientCtx=new (window.AudioContext||window.webkitAudioContext)();
    ambientGain=ambientCtx.createGain();ambientGain.gain.value=+$("#ambientVolume").value;
    ambientOsc=ambientCtx.createOscillator();ambientOsc.type="sine";ambientOsc.frequency.value=174;
    ambientOsc.connect(ambientGain).connect(ambientCtx.destination);ambientOsc.start();
    $("#ambientPlay").textContent="■";$("#ambientState").textContent="يعمل بهدوء";
  }catch(e){alert("المتصفح لا يدعم تشغيل الصوت هنا.");}
};
$("#ambientVolume").oninput=e=>{if(ambientGain)ambientGain.gain.value=+e.target.value;};

$$(".nav-item").forEach(btn=>btn.onclick=()=>{
  $$(".nav-item").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
  $$(".page-section").forEach(x=>x.classList.remove("active-section"));$("#"+btn.dataset.section).classList.add("active-section");
  $("#sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"});
});
$("#mobileMenu").onclick=()=>$("#sidebar").classList.toggle("open");
$("#themeBtn").onclick=()=>document.body.classList.toggle("light");

renderAll();renderTimer();
setInterval(updatePrayerCard,60000);
